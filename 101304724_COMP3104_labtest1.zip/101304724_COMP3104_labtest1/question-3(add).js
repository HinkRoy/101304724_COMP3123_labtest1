const fs = require('fs');
const path = require('path');

const logsDirectory = 'Logs';

// Create Logs directory if it doesn't exist
if (!fs.existsSync(logsDirectory)) {
  fs.mkdirSync(logsDirectory);
}

// Change the current working directory to the Logs directory
process.chdir(logsDirectory);

// Create 10 log files and write some text into them
for (let i = 0; i < 10; i++) {
  const logFileName = `log${i}.txt`;
  fs.writeFileSync(logFileName, `Content for ${logFileName}`);
  console.log(logFileName);
}

console.log('Log files created successfully.');
