function isString(value) {
    return typeof value === 'string';
  }
  
 
  function lowerCaseWords(mixedArray) {
    return new Promise((resolve, reject) => {
     
      const lowercasedArray = mixedArray.filter(isString).map(word => word.toLowerCase());
  
     
      if (lowercasedArray.length > 0) {
        resolve(lowercasedArray);
      } else {
        reject('No lowercase words found in the array.');
      }
    });
  }
  

  const mixedArray = ['PIZZA', 10, true, 25, false, 'Wings'];
  
  lowerCaseWords(mixedArray)
    .then(result => {
      console.log('Output:', result);
    })
    .catch(error => {
      console.error('Error:', error);
    });
  