const fs = require('fs');
const path = require('path');

const logsDirectory = 'Logs';

// Function to remove files from a directory
function removeFilesFromDirectory(directoryPath) {
  if (fs.existsSync(directoryPath)) {
    const files = fs.readdirSync(directoryPath);
    files.forEach((file) => {
      const filePath = path.join(directoryPath, file);
      console.log(`delete files...${file}`);
      fs.unlinkSync(filePath);
    });
  }
}

// Remove all files from the Logs directory and the Logs directory itself
removeFilesFromDirectory(logsDirectory);

console.log('Log files deleted successfully.');
